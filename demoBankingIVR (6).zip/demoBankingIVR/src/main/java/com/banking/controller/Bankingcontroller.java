package com.banking.controller;

import java.sql.PreparedStatement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.banking.dao.BankingOperations;
import com.banking.model.AccountDetails;
import com.banking.model.Customer;

@RestController
@RequestMapping("/bankingService")
public class Bankingcontroller {

	@Autowired
	BankingOperations operation;

	@GetMapping("/idAndPasswordVerification")
	public ResponseEntity<?> customerDetailsVerification(@RequestParam(value = "customerId") int customerId,
			@RequestParam(value = "password") String password) {
		try {
			Customer customer = operation.existCustomer(customerId, password);

			if (customer != null) {
				if (customer.getCustomerId() == customerId && customer.getPassWord() == password) {
					System.out.println("Welcome" + " " + customerId);
					return new ResponseEntity<>("Input matched", HttpStatus.OK);
				} else {
					System.out.println("Invalid credentials!!!!");
					return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
				}
			} else {
				System.out.println("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
			}

		} catch (Exception e) {
			System.out.println(e);
			return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

		}

	}

	@PostMapping(value = "/addNewCustomer", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })

	public ResponseEntity<String> newCustomer(@RequestBody Customer addNewCustomer) {
		try {
			PreparedStatement newCustomer = operation.newCustomers(addNewCustomer);
			if (newCustomer == null) {
				return new ResponseEntity<>("Data insertion failed!!", HttpStatus.NOT_FOUND);
			} else {
				return new ResponseEntity<>("Data insertion suceesfully!!", HttpStatus.OK);
			}

		} catch (Exception e) {
			System.out.println(e);
			return new ResponseEntity<>("Issues occured while inserting data", HttpStatus.EXPECTATION_FAILED);

		}

	}

	@GetMapping("/accountNumberAndPasswordVerification")
	public ResponseEntity<?> accountDetailsVerification(@RequestParam(value = "accountNumber") int accountNumber,
			@RequestParam(value = "password") String password) {
		try {
			AccountDetails accountDetails = operation.existAccountHolder(accountNumber, password);

			if (accountDetails != null) {
				if (accountDetails.getAccountNumber() == accountNumber && accountDetails.getPassword() == password) {
					System.out.println("Welcome");
					return new ResponseEntity<>("Input matched", HttpStatus.OK);
				} else {
					System.out.println("Invalid credentials!!!!");
					return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
				}
			} else {
				System.out.println("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
			}

		} catch (Exception e) {
			System.out.println(e);
			return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

		}

	}

	@GetMapping("/checkingBalanceAmount")
	public ResponseEntity<?> balanceVerification(@RequestBody AccountDetails accountDetails) {
		try {
			float balance = operation.checkBalance(accountDetails);
			if (balance == 0) {
				System.out.println("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
			} else {
				System.out.println("Your balance amount is: "+balance);
				return new ResponseEntity<>(balance, HttpStatus.OK);
			}

		} catch (Exception e) {
			System.out.println(e);
			return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

		}

	}

}
