package com.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.banking.model.AccountDetails;
import com.banking.model.Customer;
import com.banking.util.ConnectionPooling;

@Configuration
public class BankingOperations {
	@Autowired
	ConnectionPooling connectionPooling;
	Logger log=LogManager.getLogger("Log in dao class");


	public Customer existCustomer(int customerId, String password) {
		try {

			Connection newCustomerData = connectionPooling.source();
			PreparedStatement retrive = null;
			ResultSet data = null;
			String verifycustomerId = "select PASSWORD from GETBANKING_CUSTOMER where CUSTOMER_ID= '" + customerId
					+ "'And PASSWORD ='" + password + "'";
			Customer customer = new Customer();
			retrive = newCustomerData.prepareStatement(verifycustomerId);
			data = retrive.executeQuery();
			while (data.next()) {
				customer.setCustomerId(customerId);
				customer.setPassWord(password);
				log.info("data retrived");
			}
			return customer;
		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public PreparedStatement newCustomers(Customer newCustomer) {

		try {
			Connection newCustomerData = connectionPooling.source();
			PreparedStatement data = null;

			String insertDetails = "insert into GETBANKING_CUSTOMER (CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_BIRTH,MOBILE_NUMBER,ADHAR_NUMBER,EMAIL_ID,PASSWORD) values(?,?,?,?,?,?,?) ";

			data = newCustomerData.prepareStatement(insertDetails);
			data.setInt(1, newCustomer.getCustomerId());
			data.setString(2, newCustomer.getCustomerName());
			data.setDate(3, newCustomer.getCustomerDateOfBirth());
			data.setLong(4, newCustomer.getCustomerMobileNumber());
			data.setLong(5, newCustomer.getCustomerAadharNumber());
			data.setString(6, newCustomer.getCustomerEmailID());
			data.setString(7, newCustomer.getPassWord());
			data.execute();
			log.info("Data inserted sucessfully!!");
			return data;

		} catch (SQLException e1) {
			log.error("Data insertion failed!!" + e1);
			return null;

		}

	}

	public AccountDetails existAccountHolder(int accountNumber, String password) {
		try {

			Connection newCustomerData = connectionPooling.source();
			PreparedStatement retrive = null;
			ResultSet data = null;
			String verifyAccountDetails = "select PASSWORD from GETBANKING_ACCOUNT where ACCOUNT_NUMBER= '"
					+ accountNumber + "'And PASSWORD ='" + password + "'";
			AccountDetails accountDetails = new AccountDetails();
			retrive = newCustomerData.prepareStatement(verifyAccountDetails);
			data = retrive.executeQuery();
			while (data.next()) {
				accountDetails.setAccountNumber(accountNumber);
				accountDetails.setPassword(password);
				log.info("data retrived");
			}
			return accountDetails;
		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public float checkBalance(AccountDetails accountDetails) {
		try {

			String verifyBalance = "select CURRENT_BALANCE from GETBANKING_ACCOUNT where ACCOUNT_NUMBER= '"
					+ accountDetails.getAccountNumber() + "'And PASSWORD ='" + accountDetails.getPassword() + "'";
			Connection newCustomerData = connectionPooling.source();
			PreparedStatement retrive = newCustomerData.prepareStatement(verifyBalance);
			ResultSet data = retrive.executeQuery();
			float balanceAmount = 0;
			while (data.next()) {
				balanceAmount = data.getFloat("CURRENT_BALANCE");
				log.info("Balance amount processed");
			}
			return balanceAmount;
		} catch (Exception e) {
			log.error("Invalid account details!");
			return 0;

		}
	}
}
