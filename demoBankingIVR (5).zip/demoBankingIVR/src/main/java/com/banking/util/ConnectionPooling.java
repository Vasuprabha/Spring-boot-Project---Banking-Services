package com.banking.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.dbcp2.BasicDataSource;
import org.springframework.stereotype.Service;

@Service
public class ConnectionPooling {

	String Driver = null;
	String Dburl = null;
	String username = null;
	String password = null;

	private static BasicDataSource dataSource = new BasicDataSource();

	public BasicDataSource dbConnection() throws IOException {

		try {
			FileInputStream file = null;
			file = new FileInputStream("D:\\My Task\\demoBankingIVR\\src\\main\\resources\\application.properties");
			Properties property = new Properties();
			property.load(file);

			Driver = property.getProperty("spring.datasource.driverClassName");
			Dburl = property.getProperty("spring.datasource.url");
			username = property.getProperty("spring.datasource.username");
			password = property.getProperty("spring.datasource.password");
			System.out.println("Property file worked");
			dataSource = new BasicDataSource();
			dataSource.setDriverClassName(Driver);
			dataSource.setUrl(Dburl);
			dataSource.setUsername(username);
			dataSource.setPassword(password);

			dataSource.setMinIdle(5);
			dataSource.setMaxIdle(10);
			dataSource.setMaxTotal(25);
		} catch (Exception e) {
			e.printStackTrace();

		}
		return dataSource;
	}

	public String getSource(String query) throws SQLException, IOException {
		Connection connection = null;
		Statement statement = null;

		try {
			dataSource = new ConnectionPooling().dbConnection();
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			statement.execute(query);
			System.out.println("Inserting operation done!");
			return query;
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	public ResultSet getSourceSelect(String query) throws SQLException {
		Connection connection = null;
		Statement statement = null;
		ResultSet resultset = null;
		try {
			dataSource = new ConnectionPooling().dbConnection();
			connection = dataSource.getConnection();
			statement = connection.createStatement();
			resultset = statement.executeQuery(query);
			System.out.println("select query was executed");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultset;
	}
}
