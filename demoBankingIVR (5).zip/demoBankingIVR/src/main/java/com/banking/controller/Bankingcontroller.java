package com.banking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.banking.dao.BankingOperations;
import com.banking.model.Customer;

@RestController
@RequestMapping("/bankingService")
public class Bankingcontroller {

	@Autowired
	BankingOperations operation;

	@GetMapping("/idAndPasswordVerification")
	public ResponseEntity<?> verification(@RequestParam(value = "customerId") int customerId,
			@RequestParam(value = "password") String password) {
		try {
			Customer customer = operation.existCustomer(customerId, password);

			if (customer != null) {
				if (customer.getCustomerId() == customerId && customer.getPassWord() == password) {
					System.out.println("Welcome" + " " + customerId);
					return new ResponseEntity<>("Input matched", HttpStatus.OK);
				}
			} else {
				System.out.println("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.OK);
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

	}

	@PostMapping(value = "/addNewCustomer", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })

	public ResponseEntity<String> newCustomer(@RequestBody Customer addNewCustomer) {
		try {
			String newCustomer = operation.newCustomer(addNewCustomer);
			if (newCustomer == null) {
				return new ResponseEntity<>("Data insertion failed!!", HttpStatus.NOT_FOUND);
			} else {
				return new ResponseEntity<>("Data insertion suceesfully!!", HttpStatus.OK);
			}

		} catch (Exception e) {
			System.out.println(e);
			return new ResponseEntity<>("Issues occured while inserting data", HttpStatus.EXPECTATION_FAILED);

		}

	}

}
