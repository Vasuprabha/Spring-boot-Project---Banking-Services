package com.banking.model;

import java.sql.Date;

public class Customer {

	private int customerId;
	private String customerName;
	private Date customerDateOfBirth;
	private long customerMobileNumber;
	private String customerEmailID;
	private long customerAadharNumber;
	private String passWord;

	public Customer(int customerId, String passWord, String customerName, Date customerDateOfBirth,
			int customerMobileNumber, String customerEmailID, long customerAadharNumber) {
		this.customerId = customerId;
		this.passWord = passWord;
		this.customerName = customerName;
		this.customerDateOfBirth = customerDateOfBirth;
		this.customerMobileNumber = customerMobileNumber;
		this.customerEmailID = customerEmailID;
		this.customerAadharNumber = customerAadharNumber;

	}

	public Customer() {
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getCustomerDateOfBirth() {
		return customerDateOfBirth;
	}

	public void setCustomerDateOfBirth(Date customerDateOfBirth) {
		this.customerDateOfBirth = customerDateOfBirth;
	}

	public long getCustomerMobileNumber() {
		return customerMobileNumber;
	}

	public void setCustomerMobileNumber(long mobno) {
		this.customerMobileNumber = mobno;
	}

	public String getCustomerEmailID() {
		return customerEmailID;
	}

	public void setCustomerEmailID(String customerEmailID) {
		this.customerEmailID = customerEmailID;
	}

	public long getCustomerAadharNumber() {
		return customerAadharNumber;
	}

	public void setCustomerAadharNumber(long customerAadharNumber) {
		this.customerAadharNumber = customerAadharNumber;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerDateOfBirth="
				+ customerDateOfBirth + ", customerMobileNumber=" + customerMobileNumber + ", customerEmailID="
				+ customerEmailID + ", customerAadharNumber=" + customerAadharNumber + ", passWord=" + passWord + "]";
	}

}
