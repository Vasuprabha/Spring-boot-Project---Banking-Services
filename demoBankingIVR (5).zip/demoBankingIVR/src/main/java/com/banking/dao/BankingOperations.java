package com.banking.dao;

import java.sql.ResultSet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.banking.model.Customer;
import com.banking.util.ConnectionPooling;

@Configuration
public class BankingOperations {
	@Autowired
	ConnectionPooling connection;

	public Customer existCustomer(int customerId, String password) {
		Customer customer = new Customer();
		try {
			String verifycustomerId = "select PASSWORD from GETBANKING_CUSTOMER where CUSTOMER_ID= '" + customerId
					+ "'And PASSWORD ='" + password + "'";
			ResultSet data = connection.getSourceSelect(verifycustomerId);

			while (data.next()) {
				customer.setCustomerId(customerId);
				customer.setPassWord(password);
				System.out.println("data retrived");
				return customer;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;
	}

	public String newCustomer(Customer newCustomer) {
		String insernewCustomer;
		try {
			insernewCustomer = "exec SP_INSERT_CUSTOMERDETAILS @CUSTOMER_ID = '" + newCustomer.getCustomerId()
					+ "',@CUSTOMER_NAME = '" + newCustomer.getCustomerName() + "',@DATE_OF_BIRTH = '"
					+ newCustomer.getCustomerDateOfBirth() + "',@MOBILE_NUMBER = '"
					+ newCustomer.getCustomerMobileNumber() + "',@ADHAR_NUMBER = '"
					+ newCustomer.getCustomerAadharNumber() + "',@EMAIL_ID ='" + newCustomer.getCustomerEmailID()
					+ "',@PASSWORD = '" + newCustomer.getPassWord() + "'";
			String source = connection.getSource(insernewCustomer);
			return source;

		}

		catch (Exception e) {
			System.out.println(e);
			return null;
		}
	}

}
