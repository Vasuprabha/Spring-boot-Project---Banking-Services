package com.banking.model;

public class AccountDetails {
	private int accountNumber;
	private Customer customer;
	private String accountType;
	private String iFSCCode;
	private float currentBalance;
	private String password;

	public AccountDetails(int accountNumber, Customer customer, String accountType, String iFSCCode, float currentBalance,
			String password) {
		super();
		this.accountNumber = accountNumber;
		this.customer = customer;
		this.accountType = accountType;
		this.iFSCCode = iFSCCode;
		this.currentBalance = currentBalance;
		this.password = password;

	}

	public AccountDetails() {
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getiFSCCode() {
		return iFSCCode;
	}

	public void setiFSCCode(String iFSCCode) {
		this.iFSCCode = iFSCCode;
	}

	public float getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(float currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
