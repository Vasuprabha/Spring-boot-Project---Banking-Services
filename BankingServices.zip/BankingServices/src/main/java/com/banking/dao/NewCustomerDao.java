package com.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.banking.model.Customer;
import com.banking.util.ConnectionPooling;

@Configuration
public class NewCustomerDao {
	@Autowired
	ConnectionPooling connectionPooling;
	Logger log = LogManager.getLogger(NewCustomerDao.class);

	public PreparedStatement newCustomers(Customer newCustomer) {

		try {
			Connection newCustomerData = connectionPooling.source();
			PreparedStatement data = null;

			String insertDetails = "exec SP_INSERT_CUSTOMERDETAILS @CUSTOMER_ID =?,@CUSTOMER_NAME=? ,@DATE_OF_BIRTH=?,@MOBILE_NUMBER=?,@ADHAR_NUMBER=?,@EMAIL_ID=?,@PASSWORD=? ";

			data = newCustomerData.prepareStatement(insertDetails);
			data.setInt(1, newCustomer.getCustomerId());
			data.setString(2, newCustomer.getCustomerName());
			data.setDate(3, newCustomer.getCustomerDateOfBirth());
			data.setLong(4, newCustomer.getCustomerMobileNumber());
			data.setLong(5, newCustomer.getCustomerAadharNumber());
			data.setString(6, newCustomer.getCustomerEmailID());
			data.setString(7, newCustomer.getPassWord());
			data.execute();
			log.info("Data inserted sucessfully!!");
			return data;

		} catch (SQLException e) {
			log.error("Data insertion failed!!" + e);
			return null;

		}

	}
}
