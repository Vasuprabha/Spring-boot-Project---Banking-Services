package com.banking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.banking.model.AccountDetails;
import com.banking.model.Customer;
import com.banking.util.ConnectionPooling;

@Configuration
public class ExistCustomerDao {
	@Autowired
	ConnectionPooling connectionPooling;
	Logger log = LogManager.getLogger(ExistCustomerDao.class);

	public Customer existCustomer(int customerId, String password) {
		try {

			Connection newCustomerData = connectionPooling.source();
			PreparedStatement retrive = null;
			ResultSet data = null;
			Customer customer = null;
			String verifycustomerId = "exec verifyCustomerDetails @CUSTOMER_ID='" + customerId + "',@PASSWORD='"
					+ password + "'";
			retrive = newCustomerData.prepareStatement(verifycustomerId);
			data = retrive.executeQuery();
			while (data.next()) {
				customer = new Customer();
				customer.setCustomerId(customerId);
				customer.setPassWord(password);
				log.info("data retrived");
			}
			return customer;
		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public AccountDetails existAccountHolder(int accountNumber, String password) {
		try {

			Connection newCustomerData = connectionPooling.source();
			PreparedStatement retrive = null;
			ResultSet data = null;
			String verifyAccountDetails = "exec verifyAccountDetails @ACCOUNT_NUMBER='" + accountNumber
					+ "',@PASSWORD='" + password + "'";
			AccountDetails accountDetails = null;
			retrive = newCustomerData.prepareStatement(verifyAccountDetails);
			data = retrive.executeQuery();
			while (data.next()) {
				accountDetails = new AccountDetails();

				accountDetails.setAccountNumber(accountNumber);
				accountDetails.setPassword(password);
				log.info("data retrived");
			}
			return accountDetails;
		} catch (Exception e) {
			log.error(e);
			return null;
		}
	}

	public float checkBalance(AccountDetails accountDetails) {
		try {

			String verifyBalance = "exec checkBalanceDetails @ACCOUNT_NUMBER='" + accountDetails.getAccountNumber()
					+ "',@PASSWORD='" + accountDetails.getPassword() + "'";
			Connection newCustomerData = connectionPooling.source();
			PreparedStatement retrive = null;
			ResultSet data = null;
			retrive = newCustomerData.prepareStatement(verifyBalance);
			data = retrive.executeQuery();
			float balanceAmount = 0;
			while (data.next()) {
				balanceAmount = data.getFloat("CURRENT_BALANCE");
				log.info("Balance amount processed");
			}
			return balanceAmount;
		} catch (Exception e) {
			log.error("Invalid account details!");
			return 0;

		}
	}
}
