package com.banking.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.banking.dao.ExistCustomerDao;
import com.banking.model.AccountDetails;
import com.banking.model.Customer;

@RestController
@RequestMapping("/bankingService")
public class ExistCustomerController {

	@Autowired
	ExistCustomerDao operation;
	Logger log = LogManager.getLogger(ExistCustomerController.class);

	@GetMapping("/customerIdAndPasswordVerification")
	public ResponseEntity<?> customerDetailsVerification(@RequestParam(value = "customerId") int customerId,
			@RequestParam(value = "password") String password) {
		try {
			Customer customer = operation.existCustomer(customerId, password);

			if (customer != null) {
				if (customer.getCustomerId() == customerId && customer.getPassWord() == password) {
					log.info("Welcome" + " " + customerId);
					return new ResponseEntity<>("Input matched", HttpStatus.OK);
				} else {
					log.error("Invalid credentials!!!!");
					return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
				}
			} else {
				log.error("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
			}

		} catch (Exception e) {
			log.error(e);
			return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

		}

	}

	@GetMapping("/accountNumberAndPasswordVerification")
	public ResponseEntity<?> accountDetailsVerification(@RequestParam(value = "accountNumber") int accountNumber,
			@RequestParam(value = "password") String password) {
		try {
			AccountDetails accountDetails = operation.existAccountHolder(accountNumber, password);

			if (accountDetails != null) {
				if (accountDetails.getAccountNumber() == accountNumber && accountDetails.getPassword() == password) {
					log.info("Welcome");
					return new ResponseEntity<>("Input matched", HttpStatus.OK);
				} else {
					log.error("Invalid credentials!!!!");
					return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
				}
			} else {
				log.error("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
			}

		} catch (Exception e) {
			log.error(e);
			return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

		}

	}

	@GetMapping("/checkingBalanceAmount")
	public ResponseEntity<?> balanceVerification(@RequestBody AccountDetails accountDetails) {
		try {
			float balance = operation.checkBalance(accountDetails);
			if (balance == 0) {
				log.error("Invalid credentials!!!!");
				return new ResponseEntity<>("Input not matched", HttpStatus.NOT_FOUND);
			} else {
				log.info("Your balance amount is: " + balance);
				return new ResponseEntity<>(balance, HttpStatus.OK);
			}

		} catch (Exception e) {
			log.error(e);
			return new ResponseEntity<>("Issues occured while processing data", HttpStatus.EXPECTATION_FAILED);

		}

	}

}
