package com.banking.controller;

import java.sql.PreparedStatement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.banking.dao.NewCustomerDao;
import com.banking.model.Customer;

@RestController
@RequestMapping("/bankingService")
public class NewCustomerController {
	@Autowired
	NewCustomerDao operation;
	Logger log = LogManager.getLogger(NewCustomerController.class);

	@PostMapping(value = "/addCustomer", consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = {
			MediaType.APPLICATION_JSON_VALUE })

	public ResponseEntity<String> newCustomer(@RequestBody Customer addCustomer) {
		try {
			PreparedStatement newCustomer = operation.newCustomers(addCustomer);
			if (newCustomer == null) {
				log.error("Invalid credentials!!!!");
				return new ResponseEntity<>("Data insertion failed!!", HttpStatus.NOT_FOUND);
			} else {
				log.info("Data inserted");
				return new ResponseEntity<>("Data inserted suceesfully!!", HttpStatus.OK);
			}

		} catch (Exception e) {
			log.error(e);
			return new ResponseEntity<>("Issues occured while inserting data", HttpStatus.EXPECTATION_FAILED);

		}

	}
}
